<?php
$envv = getenv("FLAG") or "default";
if ($envv === "default") {
    exit("出题人懒得传环境变量FLAG，自己传一个把");
}


echo "Congratulations!请将本页面截图和解题过程发至出题人邮箱兑换flag！";
