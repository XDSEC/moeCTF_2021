from Crypto.Util.number import *

def pad(msg):
    if len(msg) == 16:
        return msg
    length = 16 - len(msg)% 16
    msg = msg + bytes([length]*length)
    return msg

def new_pad(msg):
    if len(msg) % 32 == 0:
        return msg
    length = 32 - len(msg)% 32
    msg = msg + bytes([length]*length)
    return msg

def enc(msg,key):
    assert len(msg) == 32
    assert len(key) == 16
    PT1 = msg[:16]
    PT2 = msg[16:]

    pt1 = bytes_to_long(PT1)
    pt2 = bytes_to_long(PT2)

    tmp = (((pt1>>16) & (pt1 << 23)) ^ (pt1<<7) )& (1<<127)
    ct1 = pt2 ^ tmp ^ bytes_to_long(key)
    ct2 = pt1
    return pad(long_to_bytes(ct1)) + pad(long_to_bytes(ct2))

def encrypt(msg,key):
    plain = new_pad(msg)
    key_list = []
    for i in range(16):
        key_list.append( key[i:16] + key[0:i] )
    n = len(plain)
    ciphertext = b''
    for i in range(0,n,32):
        cipher = plain[i:i+32]
        rounds = 16
        for i in range(rounds):
            cipher = enc(cipher,key_list[i])
        ciphertext += cipher
    return ciphertext